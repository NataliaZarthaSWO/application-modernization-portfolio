SET SERVEROUTPUT ON HEADING OFF TRIMSPOOL ON ECHO OFF;

SPOOL assessment_header.csv APPEND;

DECLARE
    ref_var VARCHAR2(255) := 'REF';
    dep_var VARCHAR2(255) := 'DEP';
    line_var NUMBER(10) := 0;

BEGIN
    -- no header for this file, although the format should be well documented as above and below
    FOR objects_cur IN (select do.object_name as name
                              ,do.object_type as type
                              ,do.object_id   as object_id
                         from dba_objects do
                         where upper(do.owner) = upper('&DATABASE_OWNER') )
    LOOP
	SELECT count(*) into line_var
          FROM user_source
         WHERE upper(name) = upper(objects_cur.name)
           AND rtrim(text, chr(10)) is not null
         ORDER BY line;
         DBMS_OUTPUT.PUT_LINE (1                              -- record type 1-header 2-detail
                               ||','|| objects_cur.name       -- object name
                               ||','|| objects_cur.type       -- object type
                               ||','|| objects_cur.object_id  -- object id
                               ||','|| line_var               -- code lines
        );
    END LOOP;
END;
/

SPOOL OFF;
SET SERVEROUTPUT OFF PAGESIZE 120 HEADING ON FEEDBACK OFF VERIFY ON ECHO ON TRIMSPOOL OFF DEFINE ON;
