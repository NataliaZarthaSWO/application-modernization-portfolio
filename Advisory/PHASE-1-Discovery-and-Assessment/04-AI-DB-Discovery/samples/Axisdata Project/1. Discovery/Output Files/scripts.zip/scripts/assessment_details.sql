SET SERVEROUTPUT ON HEADING OFF TRIMSPOOL ON ECHO OFF;

SPOOL assessment_details.csv APPEND;

DECLARE
    host_var VARCHAR2(255) := '';
    inst_var VARCHAR2(255) := '';
    ref_var VARCHAR2(255) := 'REF';
    dep_var VARCHAR2(255) := 'DEP';
    line_var NUMBER(10) := 0;

BEGIN
    -- no header for this file, although the format should be well documented as above and below
    SELECT host_name, instance_name INTO host_var, inst_var
      FROM v$instance;
    FOR objects_cur IN (select do.object_name as name
                              ,do.object_type as type
                              ,do.object_id   as object_id
                         from dba_objects do
                         where upper(do.owner) = upper('&DATABASE_OWNER') )
    LOOP
        -- Get references to each object
        FOR objects_ref IN (SELECT "NAME", "OWNER", "TYPE", "OBJECT_ID", "STATUS", "TYPE_LINK" FROM(
                            SELECT DISTINCT 
                              object_name as NAME, 
                              owner, object_type TYPE, hier.object_id, status ,   decode(replace(object_type,' ','_'),'PACKAGE_BODY','PACKAGE',replace(object_type,' ','_')) type_link 
                              FROM sys.DBA_objects o,  
                               (  
                                      SELECT object_id, level l, rownum ord 
                                         FROM public_dependency 
                                       CONNECT BY NOCYCLE  PRIOR object_id = referenced_object_id 
                                       START WITH referenced_object_id = objects_cur.object_id  
                            ) hier WHERE hier.object_id = o.object_id 
                            --ORDER BY ord
                            ))
        LOOP
          DBMS_OUTPUT.PUT_LINE (2                             -- record type 1-header 2-detail
                                ||','|| objects_cur.name      -- object name
                                ||','|| objects_cur.type      -- object type
                                ||','|| objects_cur.object_id -- object id
                                ||','|| objects_ref.name      -- reference name
                                ||','|| objects_ref.type      -- reference type
                                ||','|| ref_var               -- relationship
          );
        END LOOP;
        -- Get dependencies of each object
        FOR objects_dep IN ( SELECT "NAME", "OWNER", "TYPE", "OBJECT_ID", "STATUS" FROM(
                              SELECT DISTINCT 
                                 b.object_name as NAME, 
                                 b.owner, 
                                 b.object_type TYPE, 
                                 B.OBJECT_ID, 
                                 b.status
                              FROM 
                                 sys.DBA_objects b, 
                                 (SELECT object_id, referenced_object_id, level l, rownum ord 
                                  FROM public_dependency 
                                  START WITH object_id = objects_cur.object_id
                                  CONNECT BY NOCYCLE PRIOR referenced_object_id = object_id) c 
                              WHERE b.object_id = c.referenced_object_id                             
				AND b.owner NOT IN ('SYS', 'SYSTEM') 
                                AND b.object_name <> 'DUAL' 
                              --order by ord
                              ))
        LOOP
          DBMS_OUTPUT.PUT_LINE (2
                                ||','|| objects_cur.name      -- object name
                                ||','|| objects_cur.type      -- object type
                                ||','|| objects_cur.object_id -- object id
                                ||','|| objects_dep.name      -- dependency name
                                ||','|| objects_dep.type      -- dependency type
                                ||','|| dep_var               -- relationship
          );
        END LOOP;
    END LOOP;
END;
/

SPOOL OFF;
SET SERVEROUTPUT OFF PAGESIZE 120 HEADING ON FEEDBACK OFF VERIFY ON ECHO ON TRIMSPOOL OFF DEFINE ON;
